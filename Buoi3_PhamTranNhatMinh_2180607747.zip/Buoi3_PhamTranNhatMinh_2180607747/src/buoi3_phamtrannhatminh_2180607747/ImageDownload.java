/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package buoi3_phamtrannhatminh_2180607747;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
/**
 *
 * @author NotAdmin
 */

//BAI 3.2
public class ImageDownload {
       public static void main(String[] args) {
        String websiteUrl = "https://www.hutech.edu.vn";
        String outputDirectory = "downloaded_images"; // Thư mục để lưu hình ảnh

        try {
            // Kết nối và tải trang HTML
            Document document = Jsoup.connect(websiteUrl)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0 Safari/537.36")
                    .timeout(10_000) // Timeout 10 giây
                    .get();

            // Lấy tất cả các thẻ <img> từ trang
            Elements imageElements = document.select("img");

            // Tạo thư mục nếu chưa tồn tại
            java.nio.file.Files.createDirectories(java.nio.file.Paths.get(outputDirectory));

            // Duyệt qua từng thẻ <img>
            for (Element imgElement : imageElements) {
                String imageUrl = imgElement.absUrl("src"); // Lấy URL tuyệt đối của ảnh
                if (!imageUrl.isEmpty() && isImageFile(imageUrl)) {
                    System.out.println("Đang tải: " + imageUrl);
                    downloadImage(imageUrl, outputDirectory);
                }
            }

            System.out.println("Tải xuống hình ảnh hoàn tất!");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Đã xảy ra lỗi khi tải hình ảnh.");
        }
    }

    private static boolean isImageFile(String url) {
        return url.endsWith(".jpg") || url.endsWith(".jpeg") || url.endsWith(".png") || url.endsWith(".gif") || url.endsWith(".bmp");
    }


    private static void downloadImage(String imageUrl, String outputDirectory) {
        try {
            // Mở kết nối đến URL
            HttpURLConnection connection = (HttpURLConnection) new URL(imageUrl).openConnection();
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0 Safari/537.36");
            connection.setConnectTimeout(10_000); // Timeout 10 giây
            connection.setReadTimeout(10_000);

            // Tải file
            try (BufferedInputStream in = new BufferedInputStream(connection.getInputStream());
                 FileOutputStream out = new FileOutputStream(outputDirectory + "/" + getFileNameFromUrl(imageUrl))) {

                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = in.read(buffer, 0, 1024)) != -1) {
                    out.write(buffer, 0, bytesRead);
                }
            }

            connection.disconnect();
        } catch (IOException e) {
            System.out.println("Không thể tải hình ảnh: " + imageUrl);
        }
    }


    private static String getFileNameFromUrl(String url) {
        return url.substring(url.lastIndexOf("/") + 1).split("\\?")[0]; // Bỏ phần query string
    }
}
