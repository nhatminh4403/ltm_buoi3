/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package buoi3_phamtrannhatminh_2180607747;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.zip.GZIPInputStream;

/**
 *
 * @author NotAdmin
 */

//Bài 2.2
public class URLOpenStreamEx2 {
    public static void main(String[] args) throws MalformedURLException{
        String s = "https://znews.vn"; // https://zingnews.vn hướng về https://znews.vn
        String thisLine ;
        
        try {
            URL u = new URL(s);
            URLConnection connection = u.openConnection();
            
            String encoding = connection.getContentEncoding();
            InputStream inputStream = connection.getInputStream();

            // Handle compressed streams
            if ("gzip".equalsIgnoreCase(encoding)) {
                inputStream = new GZIPInputStream(inputStream);
            }
            try (BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {

                while ((thisLine = br.readLine()) != null) {
                    System.out.println(thisLine);
                }
            }
            catch(IOException e){
                System.err.println(e);
            }
            
        }catch(MalformedURLException ex){
            System.err.println(ex);
        }
        catch (IOException e) {
            System.err.println("I/O Error: " + e.getMessage());
        }
    }
}
