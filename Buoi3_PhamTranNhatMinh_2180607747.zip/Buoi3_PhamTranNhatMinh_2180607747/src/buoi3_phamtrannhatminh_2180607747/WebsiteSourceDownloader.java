/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package buoi3_phamtrannhatminh_2180607747;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.jsoup.*;

//bài 3.1
public class WebsiteSourceDownloader {

    public static void main(String[] args) {
        String websiteUrl = "https://www.hutech.edu.vn";
        String outputFileName = "E:\\JAva\\netbeans\\Buoi3_PhamTranNhatMinh_2180607747\\website_source.html";

        try {
            // Kết nối đến URL
            URL url = new URL(websiteUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Thiết lập phương thức GET
            connection.setRequestMethod("GET");

            // Kiểm tra mã trạng thái
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Đọc dữ liệu từ website
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                BufferedWriter writer = new BufferedWriter(new FileWriter(outputFileName));

                String line;
                while ((line = reader.readLine()) != null) {
                    writer.write(line);
                    writer.newLine();
                }

                // Đóng stream
                reader.close();
                writer.close();

                System.out.println("Download thành công! Source code đã được lưu vào: " + outputFileName);
            } else {
                System.out.println("Không thể kết nối đến website. Mã phản hồi: " + responseCode);
            }

            connection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Đã xảy ra lỗi trong quá trình tải xuống.");
        }
    }
}
