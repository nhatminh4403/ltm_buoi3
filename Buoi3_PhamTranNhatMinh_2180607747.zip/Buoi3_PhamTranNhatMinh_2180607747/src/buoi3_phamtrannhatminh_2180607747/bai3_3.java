/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package buoi3_phamtrannhatminh_2180607747;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 *
 * @author NotAdmin
 */
public class bai3_3 {
    public static void main(String[] args) {
        String inputFile = "E:/domains.txt"; // Tệp chứa danh sách tên miền
        String outputFile = "E:/domain_ip.txt"; // Tệp lưu kết quả

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            String domain;
            while ((domain = reader.readLine()) != null) {
                try {
                    // Lấy địa chỉ IP từ tên miền
                    InetAddress ip = InetAddress.getByName(domain);
                    String ipAddress = ip.getHostAddress();

                    // Ghi kết quả vào tệp
                    writer.write(domain + " : " + ipAddress);
                    writer.newLine();

                    // Hiển thị lên màn hình
                    System.out.println(domain + " : " + ipAddress);
                } catch (UnknownHostException e) {
                    // Trường hợp không tìm thấy IP của tên miền
                    System.err.println("Không thể tìm thấy IP cho tên miền: " + domain);
                    writer.write(domain + " : Không thể tìm thấy IP");
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            System.err.println("Lỗi khi xử lý tệp: " + e.getMessage());
        }
    }
}
